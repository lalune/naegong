#ifndef __SHOP_SCENE_H__
#define __SHOP_SCENE_H__

#include "cocos2d.h"

USING_NS_CC;

class ShopScene : public cocos2d::LayerColor
{
public:

	Sprite *sup;
	Sprite *cup;
	Sprite *full;
	Sprite *home;

	Label *s_up;
	Label *c_up;
	Label *no_money;
	Label *price;

	//Fadeout *fadeout = Fadeout::create(2.0f);

    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
	CREATE_FUNC(ShopScene);

	void initBG();
	void initMenu();
	void changeScene();

	virtual bool onTouchBegan(Touch* touch, Event* unused_event);
	virtual void onTouchEnded(Touch* touch, Event* unused_event);

	void menuCallback(Ref *Sender);
};

#endif