#include "ShopScene.h"
#include "PreScene.h"
#include "GameScene.h"
#include "SimpleAudioEngine.h"

using namespace CocosDenshion;


USING_NS_CC;

Scene * ShopScene::createScene()
{
	auto scene = Scene::create();

	auto layer = ShopScene::create();
	scene -> addChild(layer);

	return scene;
}

bool ShopScene::init()
{
	if( !LayerColor::initWithColor(Color4B::WHITE) )
	{
		return false;
	}
	GameScene::strengthnumber;

	initBG();
	SimpleAudioEngine::getInstance() -> playBackgroundMusic("Shop.mp3", true);

	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan= CC_CALLBACK_2(ShopScene::onTouchBegan,this);
	listener->onTouchEnded= CC_CALLBACK_2(ShopScene::onTouchEnded,this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener,this);

	return true;
}

void ShopScene::initBG()
{
	home = Sprite::create("home.png");
	home -> setPosition(1120, 750);
	home -> setScale(0.7, 0.7);
	this -> addChild(home, 3);

	sup = Sprite::create("s_up.png");
	sup -> setPosition(200, 400);
	sup -> setScale(0.65, 0.65);
	this -> addChild(sup, 0);

	price = Label::createWithTTF("10G","fonts/HoonSlimskinnyL.ttf", 50);
	price -> setPosition(200, 280);
	price -> setColor(Color3B::BLACK);
	this -> addChild(price, 1);

	cup = Sprite::create("c_up.png");
	cup -> setPosition(600, 400);
	cup -> setScale(0.65, 0.65);
	this -> addChild(cup, 0);

	price = Label::createWithTTF("10G","fonts/HoonSlimskinnyL.ttf", 50);
	price -> setPosition(600, 275);
	price -> setColor(Color3B::BLACK);
	this -> addChild(price, 1);

	full = Sprite::create("full.png");
	full -> setPosition(1000, 400);
	full -> setScale(0.65, 0.65);
	this -> addChild(full, 0);

	price = Label::createWithTTF("10G","fonts/HoonSlimskinnyL.ttf", 50);
	price -> setPosition(1000, 280);
	price -> setColor(Color3B::BLACK);
	this -> addChild(price, 1);
}

void ShopScene::changeScene()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic();
	Director::getInstance() -> replaceScene(PreScene::createScene());
}

bool ShopScene::onTouchBegan(Touch* touch, Event* unused_event){
	return true;
}


void ShopScene::onTouchEnded(Touch* touch, Event* unused_event){

	FadeOut *fadeout = FadeOut::create(1.25f);

	if(home->getBoundingBox().containsPoint(touch->getLocation()))
	{
		changeScene();
	}
	if(GameScene::coinnumber >= 10)
	{
		if(sup->getBoundingBox().containsPoint(touch->getLocation()))
		{
			GameScene::DeltaStreng += 1;
			GameScene::coinnumber -= 10;
			s_up = Label::createWithTTF("The strength of the force increases.","fonts/HoonSlimskinnyL.ttf", 75);
			s_up -> runAction(fadeout);
			s_up -> setPosition(640, 750);
			s_up -> setColor(Color3B::BLACK);
			this -> addChild(s_up, 2);
			CCLOG("The strength of the force increases.");
		}
		if(cup->getBoundingBox().containsPoint(touch->getLocation()))
		{
			GameScene::DeltaCoin += 1;
			GameScene::coinnumber -= 10;
			c_up = Label::createWithTTF("Profits increases","fonts/HoonSlimskinnyL.ttf", 75);
			c_up -> runAction(fadeout);
			c_up -> setPosition(640, 675);
			c_up -> setColor(Color3B::BLACK);
			this -> addChild(c_up, 2);
			CCLOG("Profits increases");
		}
	}
	else if(GameScene::coinnumber < 10)
	{
		if(sup->getBoundingBox().containsPoint(touch->getLocation()) || cup->getBoundingBox().containsPoint(touch->getLocation()))
		{
			no_money = Label::createWithTTF("Money is scarce.Collect Money!","fonts/HoonSlimskinnyL.ttf", 75);
			no_money -> runAction(fadeout);
			no_money -> setPosition(640, 600);
			no_money -> setColor(Color3B::BLACK);
			this -> addChild(no_money, 2);
			CCLOG("Money is scarce.Collect Money!");
		}
	}
}