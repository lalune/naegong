#include "PreScene.h"
#include "GameScene.h"
#include "FightScene.h"
#include "ShopScene.h"

Scene* PreScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = PreScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool PreScene::init()
{
   if( !LayerColor::initWithColor(Color4B::WHITE) )
	{
		return false;
	}
   IsPopup=false;

	initBG();

	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan= CC_CALLBACK_2(PreScene::onTouchBegan,this);
	listener->onTouchEnded= CC_CALLBACK_2(PreScene::onTouchEnded,this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener,this);

	return true;

}

void PreScene::initBG()
{

	Training = Sprite::create("Training.png");
	Training -> setPosition(300, 425);
	Training -> setScale(0.4, 0.4);
	this -> addChild(Training, 0);

	Fight = Sprite::create("Fight.png");
	Fight -> setPosition(650, 425);
	Fight -> setScale(0.4, 0.4);
	this -> addChild(Fight, 0);

	Shop = Sprite::create("Shop.png");
	Shop -> setPosition(1000, 425);
	Shop -> setScale(0.4, 0.4);
	this -> addChild(Shop, 0);

	Exit = Sprite::create("Exit.png");
	Exit -> setPosition(1200, 750);
	Exit -> setScale(0.75, 0.75);
	this -> addChild(Exit, 0);

	T = Label::createWithTTF("Training","fonts/HoonSlimskinnyL.ttf", 60);
	T -> setPosition(300, 300);
	T -> setColor(Color3B::BLACK);
	this -> addChild(T, 0);

	F = Label::createWithTTF("Fight","fonts/HoonSlimskinnyL.ttf", 60);
	F -> setPosition(650, 300);
	F -> setColor(Color3B::BLACK);
	this -> addChild(F, 0);

	S = Label::createWithTTF("Shop","fonts/HoonSlimskinnyL.ttf", 60);
	S -> setPosition(1000, 300);
	S -> setColor(Color3B::BLACK);
	this -> addChild(S, 0);

	
}

void PreScene::changeScene1()
{
	Director::getInstance() -> replaceScene(GameScene::createScene());
}
void PreScene::changeScene2()
{
	Director::getInstance() -> replaceScene(FightScene::createScene());
}
void PreScene::changeScene3()
{
	Director::getInstance() -> replaceScene(ShopScene::createScene());
}

bool PreScene::onTouchBegan(Touch* touch, Event* unused_event){
	return true;
}

void PreScene::onTouchEnded(Touch* touch, Event* unused_event){
	if(Training->getBoundingBox().containsPoint(touch->getLocation())&&!IsPopup){
			weapon = LayerColor::create(Color4B::GRAY);
			weapon -> setContentSize(Size(300, 150));
			weapon -> setPosition(540, 350);
			this -> addChild(weapon, 1);

			bow = LayerColor::create(Color4B::WHITE);
			bow -> setContentSize(Size(100, 50));
			bow -> setPosition(560, 360);
			this -> addChild(bow, 2);

			sword = LayerColor::create(Color4B::WHITE);
			sword -> setContentSize(Size(100, 50));
			sword -> setPosition(730, 360);
			this -> addChild(sword, 2);

			
			which = Label::createWithTTF("Which weapon do you like?","fonts/HoonSlimskinnyL.ttf", 30);
			which -> setPosition(700, 440);
			which -> setColor(Color3B::BLACK);
			this -> addChild(which, 3);
			
			t_bow = Label::createWithTTF("BOW","fonts/HoonSlimskinnyL.ttf", 30);
			t_bow -> setPosition(615, 380);
			t_bow -> setColor(Color3B::BLACK);
			this -> addChild(t_bow, 3);

			t_sword = Label::createWithTTF("SWORD","fonts/HoonSlimskinnyL.ttf", 30);
			t_sword -> setPosition(760, 380);
			t_sword -> setColor(Color3B::BLACK);
			this -> addChild(t_sword, 3);
			
			IsPopup=true;

			
	}
	else if(Fight->getBoundingBox().containsPoint(touch->getLocation())&&!IsPopup){

		changeScene2();
	}
	else if(Shop->getBoundingBox().containsPoint(touch->getLocation())&&!IsPopup){
		changeScene3();
	}
	if(IsPopup){
		if(bow -> getBoundingBox().containsPoint(touch->getLocation()))
			{
				GameScene::number=0;
				changeScene1();
			}
			else if(sword -> getBoundingBox().containsPoint(touch->getLocation()))
			{
				GameScene::number=1;
				changeScene1();
			}
	}
}