#ifndef __PRE_SCENE_H__
#define __PRE_SCENE_H__

#include "cocos2d.h"

USING_NS_CC;

class PreScene : public LayerColor
{
public:
	boolean IsPopup;

	Sprite *Training;
	Sprite *Shop;
	Sprite *Fight;
	Sprite *Exit;

	LayerColor *weapon;
	LayerColor *bow;
	LayerColor *sword;

	Label *t_bow;
	Label *t_sword;
	Label *which;
	Label *T;
	Label *S;
	Label *F;
	

    static Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
	CREATE_FUNC(PreScene);

	void initBG();

	void menuCallback(Ref *Sender);
	void changeScene1();
	void changeScene2();
	void changeScene3();

	virtual bool onTouchBegan(Touch* touch, Event* unused_event);
	virtual void onTouchEnded(Touch* touch, Event* unused_event);

};

#endif
