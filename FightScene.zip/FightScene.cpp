#include "FightScene.h"
#include "PreScene.h"
#include "GameScene.h"

USING_NS_CC;

Scene * FightScene::createScene()
{
	auto scene = Scene::create();

	auto layer = FightScene::create();
	scene -> addChild(layer);

	return scene;
}

bool FightScene::init()
{
	if(!LayerColor::initWithColor(Color4B::WHITE))
	{
		return false;
	}
	animatenumber = 0;

	initBG();

	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan= CC_CALLBACK_2(FightScene::onTouchBegan,this);
	listener->onTouchEnded= CC_CALLBACK_2(FightScene::onTouchEnded,this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener,this);

	return true;
}

void FightScene::initBG()
{
	GameClear = Label::createWithTTF("Game Clear!","fonts/HoonSlimskinnyL.ttf", 200);
	GameClear -> setPosition(640, 400);
	GameClear -> setColor(Color3B::BLACK);
	this -> addChild(GameClear, 3);

	home = Sprite::create("home.png");
	home -> setPosition(1120, 750);
	home -> setScale(0.7, 0.7);
	this -> addChild(home, 3);

	fmap1 = Sprite::create("fightmap_1.png");
	fmap1 -> setPosition(640, 250);
	fmap1 -> setScale(1.25, 1.25);
	this -> addChild(fmap1, 0);

	attack1 = Sprite::create("3.png");
	attack1 -> setPosition(650, 450);
	attack1 -> setScale(0.25, 0.25);
	this -> addChild(attack1, 0);

	for(int i=0;i<3;i++){	
			auto image =new Image();
			image ->initWithImageFile(StringUtils::format("%d.png",i+3));
			AnimateTexture[i] = new Texture2D();
			AnimateTexture[i]->initWithImage(image);
		}
	this->schedule(schedule_selector(FightScene::animateCharacter),0.15);
}

void FightScene::changeScene()
{
	Director::getInstance() -> replaceScene(PreScene::createScene());
}

bool FightScene::onTouchBegan(Touch* touch, Event* unused_event){
	return true;
}
int number=0;
void FightScene::animateCharacter(float dt){
	//���⿡ ������ ����ϴ°�?	
	if(isAttack){
		if(animatenumber>2){
			isAttack=false;
			animatenumber=0;
		}
		attack1 -> setTexture(AnimateTexture[animatenumber]);
		animatenumber++;
		
	}
}


void FightScene::onTouchEnded(Touch* touch, Event* unused_event){
	if(!isAttack){
		isAttack = true;
	}
	if(home->getBoundingBox().containsPoint(touch->getLocation()))
	{
		changeScene();
	}
}