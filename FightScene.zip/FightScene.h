#ifndef __FIGHT_SCENE_H__
#define __FIGHT_SCENE_H__

#include "cocos2d.h"

USING_NS_CC;

class FightScene : public cocos2d::LayerColor
{
public:

	Sprite *fmap1;
	Sprite *fmap2;
	Sprite *fmap3;
	Sprite *m1;
	Sprite *m2;
	Sprite *m3;
	Sprite *home;
	Sprite *attack1;

	Label *GameClear;

	bool isAttack;
	int animatenumber;
	void animateCharacter(float dt);

	Texture2D* AnimateTexture[1000];

    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
	CREATE_FUNC(FightScene);

	void initBG();
	void initMenu();
	void changeScene();

	virtual bool onTouchBegan(Touch* touch, Event* unused_event);
	virtual void onTouchEnded(Touch* touch, Event* unused_event);

	void menuCallback(Ref *Sender);
};

#endif