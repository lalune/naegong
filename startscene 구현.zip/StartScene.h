#ifndef __START_SCENE_H__
#define __START_SCENE_H__

#include "cocos2d.h"

USING_NS_CC;

class StartScene : public LayerColor
{
public:

	Sprite *option;

	Label *start;
	Label *exit;
	Label *title;

    static Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
	CREATE_FUNC(StartScene);

	void initBG();
	void initMenu();

	void menuCallback(Ref *Sender);
	void changeScene();

	virtual bool onTouchBegan(Touch* touch, Event* unused_event);
	virtual void onTouchEnded(Touch* touch, Event* unused_event);

};

#endif
