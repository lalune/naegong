#include "StartScene.h"
#include "PreScene.h"
#include "SimpleAudioEngine.h"

using namespace CocosDenshion;

Scene* StartScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = StartScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool StartScene::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !LayerColor::initWithColor(Color4B::WHITE) )
    {
        return false;
    }

	initBG();
	SimpleAudioEngine::getInstance() -> playBackgroundMusic("game_startmenu.mp3", true);
	initMenu();
 
	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan= CC_CALLBACK_2(StartScene::onTouchBegan,this);
	listener->onTouchEnded= CC_CALLBACK_2(StartScene::onTouchEnded,this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener,this);
	
    
    return true;
}

void StartScene::initBG()
{
	// ���ȭ��
	title = Label::createWithTTF("Grow Naegong","fonts/HoonSlimskinnyL.ttf", 170);
	title -> setColor(Color3B::MAGENTA);
	title -> setPosition(640, 600);
	this -> addChild(title, 0);

	start = Label::createWithTTF("Game Start","fonts/HoonSlimskinnyL.ttf", 125);
	start -> setColor(Color3B::BLACK);
	start -> setPosition(1000,300);
	this -> addChild(start,0);
	
}

void StartScene::initMenu()
{
	//�޴�
}


void StartScene::changeScene()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic();
	Director::getInstance() -> replaceScene(PreScene::createScene());
}

bool StartScene::onTouchBegan(Touch* touch, Event* unused_event){


	return true;
}
void StartScene::onTouchEnded(Touch* touch, Event* unused_event){
	if(start->getBoundingBox().containsPoint(touch->getLocation())){
		changeScene();
	}

}