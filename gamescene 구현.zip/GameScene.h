#ifndef __GAME_SCENE_H__
#define __GAME_SCENE_H__

#include "cocos2d.h"

USING_NS_CC;

class GameScene : public LayerColor
{
public:
	static int number;

	Sprite* coin;
	Sprite* heart;
	Sprite* background;
	Sprite* option;
	Sprite* home;
	Sprite* exit;
	Sprite* line;
	Sprite* biceps;
	Sprite* attack1;

	Label* s_number;
	Label* h_number;
	Label* c_number;

	bool isAttack;
	int animatenumber;

	static int strengthnumber;
	static int heartnumber;
	static int coinnumber;

	static int DeltaStreng;
	static int DeltaCoin;
	static int DeltaHealth;
	

	void animateCharacter(float dt);

	Texture2D* AnimateTexture[1000];

    static Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
	CREATE_FUNC(GameScene);

	void initBG();
	void changeScene();

	virtual bool onTouchBegan(Touch* touch, Event* unused_event);
	virtual void onTouchEnded(Touch* touch, Event* unused_event);

	void menuCallback(Ref *Sender);
};

#endif