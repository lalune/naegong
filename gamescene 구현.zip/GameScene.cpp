#include "GameScene.h"
#include "PreScene.h"
#include "SimpleAudioEngine.h"


using namespace CocosDenshion;

int GameScene::number=-1;
int GameScene::strengthnumber=0;
int GameScene::heartnumber=100;
int GameScene::coinnumber=0;
int GameScene::DeltaStreng=1;
int GameScene::DeltaCoin = 1;

Scene * GameScene::createScene()
{
	auto scene = Scene::create();

	auto layer = GameScene::create();
	scene -> addChild(layer);

	return scene;
}

bool GameScene::init()
{
	
	

	if( !LayerColor::initWithColor(Color4B::WHITE) )
	{
		return false;
	}

	//strengthnumber = UserDefault::getInstance() -> getIntegerForKey("wow");
	
	isAttack=false;
	animatenumber=0;
	initBG();
	SimpleAudioEngine::getInstance() -> playBackgroundMusic("boomtrap_sm.mp3", true);

	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan= CC_CALLBACK_2(GameScene::onTouchBegan,this);
	listener->onTouchEnded= CC_CALLBACK_2(GameScene::onTouchEnded,this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener,this);

	return true;
}

void GameScene::initBG()
{
	home = Sprite::create("home.png");
	home -> setPosition(1120, 750);
	home -> setScale(0.7, 0.7);
	this -> addChild(home, 3);

	exit = Sprite::create("exit.png");
	exit -> setPosition(1200, 750);
	exit -> setScale(0.7, 0.7);
	this -> addChild(exit, 3);

	line = Sprite::create("1.png");
	line -> setPosition(640, 175);
	line -> setScale(0.5, 0.5);
	this -> addChild(line, 1);

	background = Sprite::create("2.png");
	background -> setPosition(640, 400);
	background -> setScale(0.5, 0.5);
	this -> addChild(background, 1);

	coin = Sprite::create("coin.png");
	coin -> setPosition(500,175);
	coin -> setScale(0.25, 0.25);
	this -> addChild(coin, 1);

	heart = Sprite::create("heart.png");
	heart -> setPosition(925, 175);
	heart -> setScale(0.25, 0.25);
	this -> addChild(heart, 1);

	biceps = Sprite::create("biceps.png");
	biceps -> setPosition(75, 175);
	biceps -> setScale(0.25, 0.25);
	this -> addChild(biceps, 1);

	if(GameScene::number == 1){
	attack1 = Sprite::create("3.png");
	attack1 -> setPosition(650, 450);
	attack1 -> setScale(0.25, 0.25);
	this -> addChild(attack1, 0);
	}else{
	attack1 = Sprite::create("6.png");
	attack1 -> setPosition(150, 450);
	attack1 -> setScale(0.25, 0.25);
	this -> addChild(attack1, 0);
	}

	//��Ŀ������ �����ϱ�
	s_number = Label::createWithTTF(StringUtils::format("%d",strengthnumber),"fonts/HoonSlimskinnyL.ttf", 75);
	s_number -> setPosition(180, 175);
	s_number -> setColor(Color3B::BLACK);
	this -> addChild(s_number, 2);
	c_number = Label::createWithTTF(StringUtils::format("%d",coinnumber),"fonts/HoonSlimskinnyL.ttf", 75);
	c_number -> setPosition(650, 175);
	c_number -> setColor(Color3B::BLACK);
	this -> addChild(c_number, 2);
	

	if(GameScene::number == 1)
	{
		for(int i=0;i<3;i++){	
			auto image =new Image();
			image ->initWithImageFile(StringUtils::format("%d.png",i+3));
			AnimateTexture[i] = new Texture2D();
			AnimateTexture[i]->initWithImage(image);
		}
	}
	else
	{
		for(int i=0;i<2;i++){	
			auto image =new Image();
			image ->initWithImageFile(StringUtils::format("%d.png",i+6));
			AnimateTexture[i] = new Texture2D();
			AnimateTexture[i]->initWithImage(image);
		}
	}

	this->schedule(schedule_selector(GameScene::animateCharacter),0.1);

}
void GameScene::animateCharacter(float dt){
	if(isAttack){
		if(number==1&&animatenumber>2){
			isAttack=false;
			animatenumber=0;
		}else if(number==0 &&animatenumber>1){
			isAttack=false;
			animatenumber=0;
		}
		attack1 -> setTexture(AnimateTexture[animatenumber]);
		animatenumber++;
		
	}
		
}

void GameScene::changeScene()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic();
	strengthnumber -= 1;
	coinnumber -= 1;
	//UserDefault::getInstance()->setIntegerForKey("wow", strengthnumber);
	Director::getInstance() -> replaceScene(PreScene::createScene());
}

bool GameScene::onTouchBegan(Touch* touch, Event* unused_event){
	return true;
}


void GameScene::onTouchEnded(Touch* touch, Event* unused_event){
	if(!isAttack){
		strengthnumber+=DeltaStreng;
		s_number->setString(StringUtils::format("%d",strengthnumber));
		coinnumber+=DeltaCoin;
		c_number->setString(StringUtils::format("%d",coinnumber));
		isAttack = true;
	}
	if(home->getBoundingBox().containsPoint(touch->getLocation()))
	{
		changeScene();
	}
}